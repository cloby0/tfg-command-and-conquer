

//   ___                _                   _        _   ___      _      _
//  / __|_  _ _ __ _ __| |___ _ __  ___ _ _| |_ __ _| | | _ \__ _| |_ __| |_  ___ ___
//  \__ \ || | '_ \ '_ \ / -_) '  \/ -_) ' \  _/ _` | | |  _/ _` |  _/ _| ' \/ -_|_-<
//  |___/\_,_| .__/ .__/_\___|_|_|_\___|_||_\__\__,_|_| |_| \__,_|\__\__|_||_\___/__/
//           |_|  |_|
// Settings added by Supplemental Patches

#ifndef MAIN_LIGHTING_SETTINGS_FILE
#define MAIN_LIGHTING_SETTINGS_FILE

#define VANILLAAO_I 100 //[0 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200 220 240 260 280 300]

#define HELD_LIGHTING_MODE 2 //[0 1 2]
#define BLOCKLIGHT_FLICKERING 0 //[0 2 3 4 5 6 7 8 9 10]
#define AMBIENT_MULT 100 //[50 55 60 65 70 75 80 85 90 95 100 110 120 130 140 150 160 170 180 190 200]
//#define MOON_PHASE_INF_LIGHT


// Euphoria Patches


#define RANDOM_BLOCKLIGHT_SIZE 1.0 //[0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.25 2.5 2.75 3.0]

#define HAND_BLOCKLIGHT_FLICKERING 0 //[0 2 3 4 5 6 7 8 9 10]

#define SSS_STRENGTH 1 //[0 1]

//#define DIRECTIONAL_LIGHTMAP_NORMALS
#ifdef DIRECTIONAL_LIGHTMAP_NORMALS
#endif
#define DIRECTIONAL_LIGHTMAP_NORMALS_BLOCK_STRENGTH_NEW 1.0 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
#define DIRECTIONAL_LIGHTMAP_NORMALS_HANDHELD_STRENGTH 1.0 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]

//#define LIGHTMAP_CURVES
#define UPPER_LIGHTMAP_CURVE 1.0 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
#define LOWER_LIGHTMAP_CURVE 1.0 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]

#define DISTANCE_MIN_LIGHT 0 //[0 1 2 3 4 5 6 7 8 9 10]

//#define BLOCKLIGHT_CAUSTICS

#define ES_LIGHTMAP 1 //[0 1 2]

#define COLORED_ES_FLASH_LIGHTING

#endif