

//   ___                _                   _        _   ___      _      _
//  / __|_  _ _ __ _ __| |___ _ __  ___ _ _| |_ __ _| | | _ \__ _| |_ __| |_  ___ ___
//  \__ \ || | '_ \ '_ \ / -_) '  \/ -_) ' \  _/ _` | | |  _/ _` |  _/ _| ' \/ -_|_-<
//  |___/\_,_| .__/ .__/_\___|_|_|_\___|_||_\__\__,_|_| |_| \__,_|\__\__|_||_\___/__/
//           |_|  |_|
// Settings added by Supplemental Patches

#if !defined WAVING_BLOCKS_SETTINGS_FILE
#define WAVING_BLOCKS_SETTINGS_FILE

#define WAVING_SPEED 1.00 //[0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.30 1.35 1.40 1.45 1.50 1.55 1.60 1.65 1.70 1.75 1.80 1.85 1.90 1.95 2.00 2.20 2.40 2.60 2.80 3.00 3.25 3.50 3.75 4.00 4.50 5.00]
#define WAVING_I 1.00 //[0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 50.0]
#define WAVING_I_RAIN_MULT 100 //[25 50 75 100 125 150 175 200]
#define NO_WAVING_INDOORS
#define WAVING_FOLIAGE
#define WAVING_LEAVES
#define WAVING_LAVA
#define WAVING_LILY_PAD
#define WAVING_WATER_VERTEX

#ifdef NETHER
    #undef NO_WAVING_INDOORS
#endif

#ifdef WAVING_LEAVES
    #define WAVING_LEAVES_ENABLED
#endif

#if defined WAVING_FOLIAGE || defined WAVING_LEAVES_ENABLED || defined WAVING_LAVA || defined WAVING_LILY_PAD
    #define WAVING_ANYTHING_TERRAIN
#endif


// Euphoria Patches Settings


//#define WAVING_SUGAR_CANE

#define FLESH_WAVING

//#define FLESH_WAVING_ANYWHERE

#define FLESH_WAVING_SPEED 1.0 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]

#define FLESH_WAVING_STRENGTH 1.0 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]

#define WAVING_GILDED_BEADS 1 //[0 1 2 3]

#define WAVING_ROPE

#define MOLTEN_LEAD_WAVINESS 1 //[0 1 2 3]

#define SCORCHFUL_SANDSTORM_FOLIAGE_WAVING_INTENSITY 6.0 //[1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0]

#define SCORCHFUL_SANDSTORM_LEAVES_WAVING_INTENSITY 0.30 //[0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60]

#define YUNGS_SANDSTORM_WAVING_INTENSITY 0.30 //[0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60]

#endif