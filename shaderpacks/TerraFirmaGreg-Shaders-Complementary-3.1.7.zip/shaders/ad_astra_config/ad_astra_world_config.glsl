// this file is included at the end of /lib/common.glsl so it can override any user settings

// disable clouds

#ifndef WORLD_whatever //we dont have any planets we keep clouds, so i put whatever
    #undef VL_CLOUDS_ACTIVE
    #undef CLOUD_SHADOWS
#endif

#ifdef AD_ASTRA_ORBIT
	
	#define UNLIT_SKY_OBJECTS //Sun doesnt fade when over the horizon
	
	#define CELESTIAL_BOTH_HEMISPHERES //Stars still appear below the horizon
	
    #define NEBULA_AT_DAY //function not yet made
	
    #define DAYLIGHT_STARS //stars appear at day
	
	#define HAS_NO_MOON
    #define HAS_NO_ATMOSPHERE
	#undef	BORDER_FOG
    #undef  ATM_FOG_MULT
    #define ATM_FOG_MULT 0.0
    #undef  LIGHTSHAFTS_ACTIVE
    #define LIGHTSHAFTS_ACTIVE 0
    #undef  LIGHTSHAFT_BEHAVIOUR
    #define LIGHTSHAFT_BEHAVIOUR 0
#endif

#ifdef WORLD_EUROPA
    #define HAS_NO_MOON
    #define DAYLIGHT_STARS
    #undef  LENSFLARE
    #undef  BLOOM_FOG
	#undef	BORDER_FOG
    #ifdef SWITCH_PLANET_WINDSPEED
        #define PLANET_WIND_MULTIPLIER 0.04
    #endif
#endif
#ifdef WORLD_MOON
    #define HAS_NO_MOON
   // #define NEBULA_AT_DAY
    #define DAYLIGHT_STARS
    #define HAS_NO_ATMOSPHERE
	#undef	BORDER_FOG
    #define ATM_FOG_MULT 0
	#define HAS_NO_ATMOSPHERE
    #define BLOOM_STRENGTH 0.03 //[0 to 10]
#endif

#ifdef WORLD_MERCURY
    #define HAS_NO_MOON
    #define SUN_SIZE 2000 //normal is 400
 //   #define NEBULA_AT_DAY
    #define DAYLIGHT_STARS
    #define HAS_NO_ATMOSPHERE
	
#endif

#ifdef WORLD_MARS
    #define HAS_NO_MOON
    #define SUN_SIZE 100 //normal is 400
    #undef  ATM_FOG_MULT
    #define ATM_FOG_MULT 0.0
    #undef  LIGHTSHAFTS_ACTIVE
    #define LIGHTSHAFTS_ACTIVE 1
    #undef  LIGHTSHAFT_BEHAVIOUR
    #define LIGHTSHAFT_BEHAVIOUR 1
	#undef	BORDER_FOG
    #ifdef SWITCH_PLANET_WINDSPEED
        #define PLANET_WIND_MULTIPLIER 0.3
    #endif
#endif

#ifdef HAS_NO_ATMOSPHERE
    #undef LIGHTSHAFTS_ACTIVE
    #define LIGHTSHAFT_BEHAVIOUR 0
    #define rainFactor 0
    #define invRainFactor 1
    #define PLANET_WIND_MULTIPLIER 0
#endif