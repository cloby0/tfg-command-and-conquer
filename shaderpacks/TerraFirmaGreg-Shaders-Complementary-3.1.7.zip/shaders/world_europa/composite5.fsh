#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define COMPOSITE5
#define WORLD_EUROPA
#define AD_ASTRA

#include "/program/composite5.glsl"
