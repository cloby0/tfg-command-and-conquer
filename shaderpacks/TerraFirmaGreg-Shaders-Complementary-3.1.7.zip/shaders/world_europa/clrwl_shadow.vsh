#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define SHADOW
#define SHADOW_COLORWHEEL
#define WORLD_EUROPA
#define AD_ASTRA

#include "/program/shadow.glsl"
