#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define SHADOW
#define WORLD_EUROPA
#define AD_ASTRA

#include "/program/shadow.glsl"
