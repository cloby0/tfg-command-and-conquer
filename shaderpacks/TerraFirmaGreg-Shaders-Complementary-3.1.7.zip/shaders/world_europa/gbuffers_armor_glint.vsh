#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define GBUFFERS_ARMOR_GLINT
#define WORLD_EUROPA
#define AD_ASTRA

#include "/program/gbuffers_armor_glint.glsl"
