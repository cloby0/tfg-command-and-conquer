#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define GBUFFERS_SKYTEXTURED
#define WORLD_EUROPA
#define AD_ASTRA

#include "/program/gbuffers_skytextured.glsl"
